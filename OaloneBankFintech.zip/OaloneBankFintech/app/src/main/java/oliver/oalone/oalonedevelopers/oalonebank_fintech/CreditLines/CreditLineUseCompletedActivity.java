package oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import oliver.oalone.oalonedevelopers.oalonebank_fintech.InvestmentFunds.InvesmentFundTransactionCompletedActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.MainActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.MyOperationsActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.R;

public class CreditLineUseCompletedActivity extends AppCompatActivity {

    String postKey,transactionCode,ammount,currency;
    Button btGoToHome,btnMyOperations,btnSchedule;
    TextView txtTransactionCode,txtAmmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit_line_use_completed);

        //postKey = getIntent().getExtras().get("PostKey").toString();
        transactionCode = getIntent().getExtras().get("TransactionCode").toString();
        ammount = getIntent().getExtras().get("ammount").toString();
        currency = getIntent().getExtras().get("currency").toString();

        btGoToHome = findViewById(R.id.btGoToHome);
        btnMyOperations = findViewById(R.id.btnMyOperations);
        btnSchedule = findViewById(R.id.btnSchedule);
        txtTransactionCode = findViewById(R.id.txtTransactionCode);
        txtAmmount = findViewById(R.id.txtAmmount);

        if (currency.equals("PEN")) {
            txtAmmount.setText("S/"+ammount+" "+currency);
        }
        if (currency.equals("usd")) {
            txtAmmount.setText("$"+ammount+" "+currency);
        }
        txtTransactionCode.setText("Código de transacción: "+transactionCode);
        btGoToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreditLineUseCompletedActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        btnMyOperations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreditLineUseCompletedActivity.this, MyOperationsActivity.class);
                startActivity(intent);
                finish();
            }
        });
        btnSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currency.equals("PEN")) {
                    Intent intent = new Intent(CreditLineUseCompletedActivity.this, CreditLinePenScheduleActivity.class);
                    startActivity(intent);
                    finish();
                }
                if (currency.equals("USD")) {
                    Intent intent = new Intent(CreditLineUseCompletedActivity.this, CreditLineUsdScheduleActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
