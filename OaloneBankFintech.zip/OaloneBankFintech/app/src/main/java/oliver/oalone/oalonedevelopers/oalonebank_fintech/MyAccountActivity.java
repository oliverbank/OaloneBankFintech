package oliver.oalone.oalonedevelopers.oalonebank_fintech;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.xw.repo.BubbleSeekBar;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;
import me.anwarshahriar.calligrapher.Calligrapher;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines.CreditLinePenPayActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines.CreditLinePenScheduleActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines.CreditLineRequestFormActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines.CreditLineUsdPayActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines.CreditLineUsdScheduleActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines.CreditLineUsePenActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.CreditLines.CreditLineUseUsdActivity;

public class MyAccountActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference userRef,ratesRef;
    String currentUserID,profileimage,fullname,username,user_verification,document_verification,basic_account_pen,basic_account_usd,document_type,document_number,gender,
            nacionality,address,district,department,occupation,academic_degree,age, credit_line_pen, credit_line_usd,credit_line_pen_total,credit_line_pen_used,credit_line_pen_available,
            credit_line_pen_payment_month,credit_line_usd_total,credit_line_usd_used,credit_line_usd_available,credit_line_usd_payment_month,credit_line_pen_was_used,
            credit_line_usd_was_used,credit_line_pen_request_state,credit_line_usd_request_state, account_currency,basic_account_pen_trea,basic_account_usd_trea,daily_claim_pen_account,
            daily_claim_usd_account;
    CircleImageView imgProfileImage;
    ImageView imgUserVerification;
    TextView txtFullName,txtUserName,txtDcoumentVerificationWarning,txtPenBasicAccountAmmount,txtUsdBasicAccountAmmount,txtDocumentType,txtDocumentNumber,txtGender,txtAge,
            txtNationality,txtAddress,txtOcupation,txtAcademicDegree,txtCreditLineTotalPen,txtCreditLineUsedPen,txtCreditLineAvaiilablePen,txtCreditLinePaymentMonthPen,txtCreditLineTotalUsd,
            txtCreditLineUsedUsd,txtCreditLineAvaiilableUsd,txtCreditLinePaymentMonthUsd,txtCreditScore;
    Button btnDeposit,btnTransfer,btnWithdrawal,btnUseCreditPen,btnScheduleCreditPen,btnPayCreditPen,btnPayCreditUsd,btnUseCreditUsd,btnOpeartionsCreditUsd,btnCreditLinePenRequest,
            btnCreditLineUsdRequest;
    BubbleSeekBar seekBarPen,seekBarUsd;
    LinearLayout creditLineRequestLayoutPen,creditLineRequestLayoutUsd,creditLineLayoutPen,creditLineLayoutUsd;
    double credit_line_total_pen_double,credit_line__used_pen_double,credit_line_available_pen_double,credit_line_total_usd_double,credit_line__used_usd_double,credit_line_available_usd_double;
    String credit_line_pen_payment_month1,
            credit_line_pen_payment_month2,credit_line_pen_payment_month3,credit_line_pen_payment_month4,credit_line_pen_payment_month5,credit_line_pen_payment_month6,
            credit_line_pen_payment_month7,credit_line_pen_payment_month8,credit_line_pen_payment_month9,credit_line_pen_payment_month10,credit_line_pen_payment_month11,
            credit_line_pen_payment_month12,credit_line_start_day_payment,credit_line_end_day_payment,defaulter_credit_pen_daily_rate,new_payment_st,quotes_acomulated_st,
            credit_line_pen_default_day1,credit_line_pen_default_day2,credit_line_pen_default_day3,credit_line_pen_default_day4,credit_line_pen_default_day5,
            credit_line_pen_default_day6,credit_line_pen_default_day7,credit_line_pen_default_day8,credit_line_pen_default_day9,credit_line_pen_default_day10,credit_score,
            min_ammount_pen_account,min_ammount_usd_account;
    int credit_line_pen_payment_year1,credit_line_pen_payment_year2,credit_line_pen_payment_year3,credit_line_pen_payment_year4,
            credit_line_pen_payment_year5,credit_line_pen_payment_year6,credit_line_pen_payment_year7,credit_line_pen_payment_year8,credit_line_pen_payment_year9,credit_line_pen_payment_year10,
            credit_line_pen_payment_year11,credit_line_pen_payment_year12;
    int month,day, start_day, end_day,current_year;
    double credit_month_double1,credit_month_double2,credit_month_double3,credit_month_double4,credit_month_double5,credit_month_double6,credit_month_double7,
            credit_month_double8,credit_month_double9,credit_month_double10,credit_month_double11,credit_month_double12,defaulter_credit_pen_daily_rate_double,defaulter_rate,
            new_payment, quotes_acomulated,pen_account,usd_account,pen_trea,usd_trea;
    private ProgressDialog loadingBar;
    String credit_line_request_currency;
    String credit_line_request_condition;
    LinearLayout penAccountLayout,usdAccountLayout;
    ImageButton showMyQrCode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);

        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();
        userRef = FirebaseDatabase.getInstance().getReference().child("Users");
        ratesRef = FirebaseDatabase.getInstance().getReference().child("Rates");

        imgProfileImage = findViewById(R.id.imgProfileImage);
        txtFullName = findViewById(R.id.txtFullName);
        txtUserName = findViewById(R.id.txtUserName);
        imgUserVerification = findViewById(R.id.imgUserVerification);
        txtDcoumentVerificationWarning = findViewById(R.id.txtDcoumentVerificationWarning);
        txtPenBasicAccountAmmount= findViewById(R.id.txtPenBasicAccountAmmount);
        txtUsdBasicAccountAmmount = findViewById(R.id.txtUsdBasicAccountAmmount);
        txtDocumentType = findViewById(R.id.txtDocumentType);
        txtDocumentNumber = findViewById(R.id.txtDocumentNumber);
        txtGender = findViewById(R.id.txtGender);
        txtAge = findViewById(R.id.txtAge);
        txtNationality = findViewById(R.id.txtNationality);
        txtAddress = findViewById(R.id.txtAddress);
        txtOcupation = findViewById(R.id.txtOcupation);
        txtAcademicDegree = findViewById(R.id.txtAcademicDegree);
        btnDeposit = findViewById(R.id.btnDeposit);
        btnTransfer = findViewById(R.id.btnTransfer);
        btnWithdrawal = findViewById(R.id.btnWithdrawal);
        seekBarPen = findViewById(R.id.seekBarPen);
        seekBarUsd = findViewById(R.id.seekBarUsd);
        creditLineRequestLayoutPen = findViewById(R.id.creditLineRequestLayoutPen);
        creditLineRequestLayoutUsd = findViewById(R.id.creditLineRequestLayoutUsd);
        creditLineLayoutPen = findViewById(R.id.creditLineLayoutPen);
        creditLineLayoutUsd = findViewById(R.id.creditLineLayoutUsd);
        txtCreditLineTotalPen = findViewById(R.id.txtCreditLineTotalPen);
        txtCreditLineUsedPen = findViewById(R.id.txtCreditLineUsedPen);
        txtCreditLineAvaiilablePen = findViewById(R.id.txtCreditLineAvaiilablePen);
        txtCreditLinePaymentMonthPen = findViewById(R.id.txtCreditLinePaymentMonthPen);
        btnUseCreditPen = findViewById(R.id.btnUseCreditPen);
        btnScheduleCreditPen = findViewById(R.id.btnScheduleCreditPen);
        btnPayCreditPen = findViewById(R.id.btnPayCreditPen);
        btnPayCreditUsd = findViewById(R.id.btnPayCreditUsd);
        btnUseCreditUsd= findViewById(R.id.btnUseCreditUsd);
        btnOpeartionsCreditUsd = findViewById(R.id.btnOpeartionsCreditUsd);
        txtCreditLineTotalUsd = findViewById(R.id.txtCreditLineTotalUsd);
        txtCreditLineUsedUsd = findViewById(R.id.txtCreditLineUsedUsd);
        txtCreditLineAvaiilableUsd = findViewById(R.id.txtCreditLineAvaiilableUsd);
        txtCreditLinePaymentMonthUsd = findViewById(R.id.txtCreditLinePaymentMonthUsd);
        txtCreditScore= findViewById(R.id.txtCreditScore);
        loadingBar = new ProgressDialog(this);
        btnCreditLinePenRequest = findViewById(R.id.btnCreditLinePenRequest);
        btnCreditLineUsdRequest = findViewById(R.id.btnCreditLineUsdRequest);
        penAccountLayout= findViewById(R.id.penAccountLayout);
        usdAccountLayout = findViewById(R.id.usdAccountLayout);
        showMyQrCode = findViewById(R.id.showMyQrCode);

        txtDcoumentVerificationWarning.getLayoutParams().height = 0;

        /*imgProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, ProfileImageSetUpActivity.class);
                startActivity(intent);
            }
        });*/

        loadingBar.setTitle("Preparando todo...");
        loadingBar.setMessage("Cargando...");
        loadingBar.show();
        loadingBar.setCanceledOnTouchOutside(false);
        loadingBar.setCancelable(false);

        penAccountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                account_currency = "PEN";
                showAccountOptions();
            }
        });

        usdAccountLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                account_currency = "USD";
                showAccountOptionsUsd();
            }
        });

        showMyQrCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, MyQrCodeActivity.class);
                startActivity(intent);
            }
        });

        userRef.child(currentUserID).addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists())
                {
                    profileimage = dataSnapshot.child("profileimage").getValue().toString();
                    fullname = dataSnapshot.child("fullname").getValue().toString();
                    username = dataSnapshot.child("username").getValue().toString();
                    user_verification = dataSnapshot.child("user_verification").getValue().toString();
                    document_verification = dataSnapshot.child("document_verification").getValue().toString();
                    basic_account_pen = dataSnapshot.child("basic_account_pen").getValue().toString();
                    basic_account_usd = dataSnapshot.child("basic_account_usd").getValue().toString();
                    document_type = dataSnapshot.child("document_type").getValue().toString();
                    document_number = dataSnapshot.child("document_number").getValue().toString();
                    age = dataSnapshot.child("age").getValue().toString();
                    gender = dataSnapshot.child("gender").getValue().toString();
                    nacionality = dataSnapshot.child("nacionality").getValue().toString();
                    address = dataSnapshot.child("address").getValue().toString();
                    district = dataSnapshot.child("district").getValue().toString();
                    department = dataSnapshot.child("department").getValue().toString();
                    occupation = dataSnapshot.child("occupation").getValue().toString();
                    academic_degree = dataSnapshot.child("academic_degree").getValue().toString();
                    credit_line_pen_was_used = dataSnapshot.child("credit_line_pen_was_used").getValue().toString();
                    credit_line_usd_was_used = dataSnapshot.child("credit_line_usd_was_used").getValue().toString();
                    credit_score = dataSnapshot.child("credit_score").getValue().toString();
                    daily_claim_pen_account = dataSnapshot.child("daily_claim_pen_account").getValue().toString();
                    daily_claim_usd_account = dataSnapshot.child("daily_claim_usd_account").getValue().toString();

                    //Monthly Payments
                    credit_line_pen_payment_month1 = dataSnapshot.child("credit_line_pen_payment_month1").getValue().toString();
                    credit_line_pen_payment_month2 = dataSnapshot.child("credit_line_pen_payment_month2").getValue().toString();
                    credit_line_pen_payment_month3 = dataSnapshot.child("credit_line_pen_payment_month3").getValue().toString();
                    credit_line_pen_payment_month4 = dataSnapshot.child("credit_line_pen_payment_month4").getValue().toString();
                    credit_line_pen_payment_month5 = dataSnapshot.child("credit_line_pen_payment_month5").getValue().toString();
                    credit_line_pen_payment_month6 = dataSnapshot.child("credit_line_pen_payment_month6").getValue().toString();
                    credit_line_pen_payment_month7 = dataSnapshot.child("credit_line_pen_payment_month7").getValue().toString();
                    credit_line_pen_payment_month8 = dataSnapshot.child("credit_line_pen_payment_month8").getValue().toString();
                    credit_line_pen_payment_month9 = dataSnapshot.child("credit_line_pen_payment_month9").getValue().toString();
                    credit_line_pen_payment_month10 = dataSnapshot.child("credit_line_pen_payment_month10").getValue().toString();
                    credit_line_pen_payment_month11 = dataSnapshot.child("credit_line_pen_payment_month11").getValue().toString();
                    credit_line_pen_payment_month12 = dataSnapshot.child("credit_line_pen_payment_month12").getValue().toString();

                    credit_line_pen_payment_year1 = dataSnapshot.child("credit_line_pen_payment_year1").getValue(Integer.class);
                    credit_line_pen_payment_year2 = dataSnapshot.child("credit_line_pen_payment_year2").getValue(Integer.class);
                    credit_line_pen_payment_year3 = dataSnapshot.child("credit_line_pen_payment_year3").getValue(Integer.class);
                    credit_line_pen_payment_year4 = dataSnapshot.child("credit_line_pen_payment_year4").getValue(Integer.class);
                    credit_line_pen_payment_year5 = dataSnapshot.child("credit_line_pen_payment_year5").getValue(Integer.class);
                    credit_line_pen_payment_year6 = dataSnapshot.child("credit_line_pen_payment_year6").getValue(Integer.class);
                    credit_line_pen_payment_year7 = dataSnapshot.child("credit_line_pen_payment_year7").getValue(Integer.class);
                    credit_line_pen_payment_year8 = dataSnapshot.child("credit_line_pen_payment_year8").getValue(Integer.class);
                    credit_line_pen_payment_year9 = dataSnapshot.child("credit_line_pen_payment_year9").getValue(Integer.class);
                    credit_line_pen_payment_year10 = dataSnapshot.child("credit_line_pen_payment_year10").getValue(Integer.class);
                    credit_line_pen_payment_year11 = dataSnapshot.child("credit_line_pen_payment_year11").getValue(Integer.class);
                    credit_line_pen_payment_year12 = dataSnapshot.child("credit_line_pen_payment_year12").getValue(Integer.class);

                    credit_line_pen_default_day1 = dataSnapshot.child("credit_line_pen_default_day1").getValue().toString();
                    credit_line_pen_default_day2 = dataSnapshot.child("credit_line_pen_default_day2").getValue().toString();
                    credit_line_pen_default_day3 = dataSnapshot.child("credit_line_pen_default_day3").getValue().toString();
                    credit_line_pen_default_day4 = dataSnapshot.child("credit_line_pen_default_day4").getValue().toString();
                    credit_line_pen_default_day5 = dataSnapshot.child("credit_line_pen_default_day5").getValue().toString();
                    credit_line_pen_default_day6 = dataSnapshot.child("credit_line_pen_default_day6").getValue().toString();
                    credit_line_pen_default_day7 = dataSnapshot.child("credit_line_pen_default_day7").getValue().toString();
                    credit_line_pen_default_day8 = dataSnapshot.child("credit_line_pen_default_day8").getValue().toString();
                    credit_line_pen_default_day9 = dataSnapshot.child("credit_line_pen_default_day9").getValue().toString();
                    credit_line_pen_default_day10 = dataSnapshot.child("credit_line_pen_default_day10").getValue().toString();

                    Picasso.with(MyAccountActivity.this).load(profileimage).fit().centerCrop().into(imgProfileImage);
                    txtFullName.setText(fullname);
                    txtUserName.setText("@"+username);
                    txtPenBasicAccountAmmount.setText("S/"+basic_account_pen);
                    txtUsdBasicAccountAmmount.setText("$"+basic_account_usd);
                    txtDocumentType.setText("Tipo de documento: "+document_type);
                    txtDocumentNumber.setText("Nùmero de documento: "+document_number);
                    txtGender.setText("Género: "+gender);
                    txtAge.setText("Edad: "+age+" años");
                    txtNationality.setText("Nacionalidad: "+nacionality);
                    txtAddress.setText("Domicilio: "+address+", "+district+", "+department);
                    txtOcupation.setText("Ocupación: "+occupation);
                    txtAcademicDegree.setText("Grado académico: "+academic_degree);

                    txtDcoumentVerificationWarning.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (document_verification.equals("none"))
                            {
                                Intent intent = new Intent(MyAccountActivity.this,DocumentVerificationActivity.class);
                                startActivity(intent);
                            }
                            if (document_verification.equals("false"))
                            {
                                Intent intent = new Intent(MyAccountActivity.this,DocumentVerificationActivity.class);
                                startActivity(intent);
                            }
                            if (document_verification.equals("in_progress"))
                            {
                                //Show dialog (in_progress)
                            }
                        }
                    });

                    if (document_verification.equals("none"))
                    {
                        txtDcoumentVerificationWarning.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                    }

                    if (document_verification.equals("false"))
                    {
                        txtDcoumentVerificationWarning.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                        HashMap userMap = new HashMap();
                        userMap.put("user_verification","false");
                        userRef.child(currentUserID).updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {

                            }
                        });
                    }
                    if (document_verification.equals("in_progress"))
                    {
                        txtDcoumentVerificationWarning.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                        txtDcoumentVerificationWarning.setText("Tus documentos están siendo verificados...");
                        txtDcoumentVerificationWarning.setBackgroundResource(R.color.backgroundColor);
                        imgUserVerification.setImageResource(R.drawable.transaction_in_progress);
                    }
                    if (document_verification.equals("true"))
                    {

                        txtDcoumentVerificationWarning.getLayoutParams().height = 0;
                        HashMap userMap = new HashMap();
                        userMap.put("user_verification","true");
                        userRef.child(currentUserID).updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {

                            }
                        });
                    }
                    if (user_verification.equals("true"))
                    {
                        imgUserVerification.setImageResource(R.drawable.transaction_completed);
                    }
                    if (user_verification.equals("false"))
                    {
                        imgUserVerification.setImageResource(R.drawable.error_icon);
                    }
                    if (user_verification.equals("progress"))
                    {
                        imgUserVerification.setImageResource(R.drawable.transaction_in_progress);
                    }

                    credit_line_pen = dataSnapshot.child("credit_line_pen").getValue().toString();
                    credit_line_usd = dataSnapshot.child("credit_line_usd").getValue().toString();
                    credit_line_pen_request_state = dataSnapshot.child("credit_line_pen_request_state").getValue().toString();
                    credit_line_usd_request_state = dataSnapshot.child("credit_line_usd_request_state").getValue().toString();
                    creditLineLayoutPen.getLayoutParams().height = 0;
                    creditLineLayoutUsd.getLayoutParams().height = 0;

                    if (credit_line_pen_request_state.equals("requested"))
                    {
                        btnCreditLinePenRequest.setEnabled(false);
                        btnCreditLinePenRequest.setText("Solicitud enviada para linea en Soles (S/)");
                        btnCreditLinePenRequest.setTextColor(Color.BLACK);
                        btnCreditLinePenRequest.setBackground(getDrawable(R.drawable.edit_text_background1));
                    }
                    if (credit_line_usd_request_state.equals("requested"))
                    {
                        btnCreditLineUsdRequest.setEnabled(false);
                        btnCreditLineUsdRequest.setText("Solicitud enviada para linea en Soles (S/)");
                        btnCreditLineUsdRequest.setTextColor(Color.BLACK);
                        btnCreditLineUsdRequest.setBackground(getDrawable(R.drawable.edit_text_background1));
                    }
                    if (credit_line_usd_request_state.equals("approved"))
                    {
                        btnCreditLineUsdRequest.setEnabled(false);
                        btnCreditLineUsdRequest.setText("Solicitud enviada para linea en Soles (S/)");
                        btnCreditLineUsdRequest.setTextColor(Color.BLACK);
                        btnCreditLineUsdRequest.setBackground(getDrawable(R.drawable.edit_text_background1));
                    }
                    if (credit_line_pen_request_state.equals("approved"))
                    {
                        btnCreditLineUsdRequest.setEnabled(false);
                        btnCreditLineUsdRequest.setText("Solicitud enviada para linea en Soles (S/)");
                        btnCreditLineUsdRequest.setTextColor(Color.BLACK);
                        btnCreditLineUsdRequest.setBackground(getDrawable(R.drawable.edit_text_background1));
                    }

                    if (credit_line_usd_request_state.equals("denied"))
                    {
                        btnCreditLineUsdRequest.setEnabled(false);
                        btnCreditLineUsdRequest.setText("Solicitud Denegada para linea en Soles (S/)");
                        btnCreditLineUsdRequest.setTextColor(Color.WHITE);
                        btnCreditLineUsdRequest.setBackground(getDrawable(R.drawable.button3_background));
                    }
                    if (credit_line_pen_request_state.equals("denied"))
                    {
                        btnCreditLineUsdRequest.setEnabled(false);
                        btnCreditLineUsdRequest.setText("Solicitud Denegada para linea en Dólares ($)");
                        btnCreditLineUsdRequest.setTextColor(Color.WHITE);
                        btnCreditLineUsdRequest.setBackground(getDrawable(R.drawable.button3_background));
                    }

                    if (credit_line_pen.equals("true"))
                    {
                        creditLineLayoutPen.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                        creditLineRequestLayoutPen.getLayoutParams().height = 0;
                    }
                    if (credit_line_usd.equals("true"))
                    {
                        creditLineLayoutUsd.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                        creditLineRequestLayoutUsd.getLayoutParams().height = 0;
                    }
                    if (credit_line_pen.equals("false"))
                    {
                        creditLineRequestLayoutPen.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                        creditLineLayoutPen.getLayoutParams().height = 0;
                    }
                    if (credit_line_usd.equals("false"))
                    {
                        creditLineRequestLayoutUsd.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
                        creditLineLayoutUsd.getLayoutParams().height = 0;
                    }


                    seekBarPen.setEnabled(false);
                    seekBarUsd.setEnabled(false);
                    //Credit Line (Soles)
                    credit_line_pen_total = dataSnapshot.child("credit_line_pen_total").getValue().toString();
                    credit_line_pen_used = dataSnapshot.child("credit_line_pen_used").getValue().toString();
                    credit_line_pen_available = dataSnapshot.child("credit_line_pen_available").getValue().toString();
                    //credit_line_pen_payment_month = dataSnapshot.child("credit_line_pen_payment_month").getValue().toString();

                    credit_line_total_pen_double = Double.parseDouble(credit_line_pen_total);
                    credit_line__used_pen_double = Double.parseDouble(credit_line_pen_used);
                    credit_line_available_pen_double = Double.parseDouble(credit_line_pen_available);

                    credit_line_available_pen_double = credit_line_total_pen_double-credit_line__used_pen_double;
                    DecimalFormat decimalFormat = new DecimalFormat("0.00");
                    String available_pen = decimalFormat.format(credit_line_available_pen_double);

                    HashMap userMap = new HashMap();
                    userMap.put("credit_line_pen_available",available_pen);
                    userRef.child(currentUserID).updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            txtCreditLineTotalPen.setText("Línea Aprobada: S/ "+credit_line_pen_total);
                            txtCreditLineUsedPen.setText("S/"+credit_line_pen_used);
                            txtCreditLineAvaiilablePen.setText("S/"+credit_line_pen_available);
                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/"+credit_line_pen_payment_month);

                            seekBarPen.getConfigBuilder()
                                    .min(0)
                                    .max((float) credit_line_total_pen_double)
                                    .progress((float) credit_line__used_pen_double)
                                    .build();

                            loadPaymentMonthPen();
                        }
                    });

                    //Credit Line (Dollars)
                    credit_line_usd_total = dataSnapshot.child("credit_line_usd_total").getValue().toString();
                    credit_line_usd_used = dataSnapshot.child("credit_line_usd_used").getValue().toString();
                    credit_line_usd_available = dataSnapshot.child("credit_line_usd_available").getValue().toString();
                    //credit_line_usd_payment_month = dataSnapshot.child("credit_line_pen_payment_month").getValue().toString();

                    credit_line_total_usd_double = Double.parseDouble(credit_line_usd_total);
                    credit_line__used_usd_double = Double.parseDouble(credit_line_usd_used);
                    credit_line_available_usd_double = Double.parseDouble(credit_line_usd_available);

                    credit_line_available_usd_double = credit_line_total_usd_double-credit_line__used_usd_double;
                    String available_usd = decimalFormat.format(credit_line_available_usd_double);

                    userMap.put("credit_line_usd_available",available_usd);
                    userRef.child(currentUserID).updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            txtCreditLineTotalUsd.setText("Línea Aprobada: $/ "+credit_line_usd_total);
                            txtCreditLineUsedUsd.setText("$/"+credit_line_usd_used);
                            txtCreditLineAvaiilableUsd.setText("$/"+credit_line_usd_available);
                            //txtCreditLinePaymentMonthUsd.setText("PAGO DEL MES: $/"+credit_line_usd_payment_month);

                            seekBarUsd.getConfigBuilder()
                                    .min(0)
                                    .max((float) credit_line_total_usd_double)
                                    .progress((float) credit_line__used_usd_double)
                                    .build();

                            loadPaymentMonthUsd();
                        }
                    });

                    if (credit_score.equals("0"))
                    {
                        txtCreditScore.setText("Calificación Crediticia: Normal");
                    }
                    if (credit_score.equals("1"))
                    {
                        txtCreditScore.setText("Calificación Crediticia: Problemas Potenciales");
                    }
                    if (credit_score.equals("2"))
                    {
                        txtCreditScore.setText("Calificación Crediticia: Deficiente");
                    }
                    if (credit_score.equals("3"))
                    {
                        txtCreditScore.setText("Calificación Crediticia: Dudoso");
                    }
                    if (credit_score.equals("4"))
                    {
                        txtCreditScore.setText("Calificación Crediticia: Pérdida");
                    }
                    if (credit_score.equals("5"))
                    {
                        txtCreditScore.setText("Calificación Crediticia: Desconocido");
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                loadingBar.dismiss();
                Toast.makeText(MyAccountActivity.this, "Error al cargar información", Toast.LENGTH_SHORT).show();
            }
        });

        btnCreditLinePenRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                credit_line_request_currency = "PEN";
                if (user_verification.equals("false"))
                {
                    showRestrictionDialog();
                }
                if (user_verification.equals("progress"))
                {
                    showRestrictionDialog();
                }
                if (credit_score.equals("1"))
                {
                    showRiskRestrictionDialog();
                }
                if (credit_score.equals("2"))
                {
                    showRiskRestrictionDialog();
                }
                if (credit_score.equals("3"))
                {
                    showRiskRestrictionDialog();
                }
                if (credit_score.equals("4"))
                {
                    showRiskRestrictionDialog();
                }
                if (user_verification.equals("false"))
                {
                    showRestrictionDialog();
                }
                if (user_verification.equals("true"))
                {
                    showUserConditionDialog();
                }
            }
        });

        btnCreditLineUsdRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                credit_line_request_currency = "USD";
                if (user_verification.equals("false"))
                {
                    showRestrictionDialog();
                }
                if (user_verification.equals("progress"))
                {
                    showRestrictionDialog();
                }
                if (credit_score.equals("1"))
                {
                    showRiskRestrictionDialog();
                }
                if (credit_score.equals("2"))
                {
                    showRiskRestrictionDialog();
                }
                if (credit_score.equals("3"))
                {
                    showRiskRestrictionDialog();
                }
                if (credit_score.equals("4"))
                {
                    showRiskRestrictionDialog();
                }
                if (user_verification.equals("true") && credit_score.equals("0"))
                {
                    showUserConditionDialog();
                }
                if (user_verification.equals("true") && credit_score.equals("5"))
                {
                    showUserConditionDialog();
                }
            }
        });

        btnUseCreditPen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, CreditLineUsePenActivity.class);
                startActivity(intent);
            }
        });

        btnScheduleCreditPen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (credit_line_pen_was_used.equals("false"))
                {
                    Toast.makeText(MyAccountActivity.this, "Aun no has usado esta línea de crédito", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent intent = new Intent(MyAccountActivity.this, CreditLinePenScheduleActivity.class);
                    startActivity(intent);
                }
            }
        });
        btnPayCreditPen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, CreditLinePenPayActivity.class);
                startActivity(intent);
            }
        });
        btnUseCreditUsd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, CreditLineUseUsdActivity.class);
                startActivity(intent);
            }
        });
        btnOpeartionsCreditUsd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (credit_line_usd_was_used.equals("false"))
                {
                    Toast.makeText(MyAccountActivity.this, "Aun no has usado esta línea de crédito", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent intent = new Intent(MyAccountActivity.this, CreditLineUsdScheduleActivity.class);
                    startActivity(intent);
                }
            }
        });
        btnPayCreditUsd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, CreditLineUsdPayActivity.class);
                startActivity(intent);
            }
        });
        btnDeposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, DepositActivity.class);
                startActivity(intent);
            }
        });
        btnTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, TransferActivity.class);
                startActivity(intent);
            }
        });
        btnWithdrawal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyAccountActivity.this, WithdrawalActivity.class);
                startActivity(intent);
            }
        });


        seekBarPen.setOnProgressChangedListener(new BubbleSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(int progress, float progressFloat) {

            }

            @Override
            public void getProgressOnActionUp(int progress, float progressFloat) {

            }

            @Override
            public void getProgressOnFinally(int progress, float progressFloat) {

            }
        });
    }

    DecimalFormat decimalFormat = new DecimalFormat("0.00");
    private void showAccountOptionsUsd() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View pin_dialog = inflater.inflate(R.layout.pen_account_options,null);

        final TextView txtBasicAccountAmmount,txtTrea,txtInterestAmmount;
        final Button btnClaimInerest;

        txtBasicAccountAmmount = pin_dialog.findViewById(R.id.txtBasicAccountAmmount);
        txtTrea = pin_dialog.findViewById(R.id.txtTrea);
        txtInterestAmmount = pin_dialog.findViewById(R.id.txtInterestAmmount);
        btnClaimInerest = pin_dialog.findViewById(R.id.btnClaimInerest);

        pen_account = Double.parseDouble(basic_account_pen);
        usd_account = Double.parseDouble(basic_account_usd);
        pen_trea = Double.parseDouble(basic_account_pen_trea);
        usd_trea = Double.parseDouble(basic_account_usd_trea);

        if (account_currency.equals("USD"))
        {
            dialog.setTitle("Cuenta Básica Dólares ($ - USD)");
            dialog.setMessage("Información: ");
            txtBasicAccountAmmount.setText("$"+basic_account_usd);
            txtTrea.setText(basic_account_usd_trea+"%");
            if (daily_claim_usd_account.equals("true"))
            {
                btnClaimInerest.setText("ESPERA A MAÑANA");
                btnClaimInerest.setEnabled(false);
                btnClaimInerest.setBackgroundResource(R.color.backgroundColor);
                txtInterestAmmount.setText("$0.00");

            }
            if (daily_claim_usd_account.equals("false"))
            {
                //Calculate daily rate:
                double factor_1 = ((usd_trea/100)+1);
                double daily_rate_pen = Math.pow(factor_1,(0.0027397260273))-1;
                double interest_gained = usd_account*daily_rate_pen;
                String interest_gained_st = decimalFormat.format(interest_gained);
                txtInterestAmmount.setText("$"+interest_gained_st);
            }
        }

        btnClaimInerest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingBar.setTitle("Entregando Intereses...");
                loadingBar.setMessage("Cargando...");
                loadingBar.show();
                loadingBar.setCanceledOnTouchOutside(false);
                loadingBar.setCancelable(false);
                //Set min ammount of money in the account
                double min_ammount_pen = Double.parseDouble(min_ammount_pen_account);
                double min_ammount_usd = Double.parseDouble(min_ammount_usd_account);

                HashMap hashMap = new HashMap();

                if (account_currency.equals("USD"))
                {
                    if (daily_claim_usd_account.equals("false"))
                    {
                        //Calculate daily rate:
                        double factor_1 = ((usd_trea/100)+1);
                        double daily_rate_pen = Math.pow(factor_1,(0.0027397260273))-1;
                        double interest_gained = usd_account*daily_rate_pen;

                        double total_money_usd = interest_gained+usd_account;
                        String total_money_usd_st = decimalFormat.format(total_money_usd);

                        hashMap.put("basic_account_usd",total_money_usd_st);
                        hashMap.put("daily_claim_usd_account", "true");

                        btnClaimInerest.setText("ESPERA A MAÑANA");
                        btnClaimInerest.setEnabled(false);
                        btnClaimInerest.setBackgroundResource(R.color.backgroundColor);
                        txtInterestAmmount.setText("$0.00");

                        userRef.child(currentUserID).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {
                                if (task.isSuccessful())
                                {
                                    Toast.makeText(MyAccountActivity.this, "Has cobrado tus intereses exitosamente!", Toast.LENGTH_LONG).show();
                                    loadingBar.dismiss();
                                }
                                else
                                {
                                    String message = task.getException().getMessage();
                                    Toast.makeText(MyAccountActivity.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            }
        });
        dialog.setView(pin_dialog);
        dialog.show();
    }

    private void showAccountOptions() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View pin_dialog = inflater.inflate(R.layout.pen_account_options,null);

        final TextView txtBasicAccountAmmount,txtTrea,txtInterestAmmount;
        final Button btnClaimInerest;

        txtBasicAccountAmmount = pin_dialog.findViewById(R.id.txtBasicAccountAmmount);
        txtTrea = pin_dialog.findViewById(R.id.txtTrea);
        txtInterestAmmount = pin_dialog.findViewById(R.id.txtInterestAmmount);
        btnClaimInerest = pin_dialog.findViewById(R.id.btnClaimInerest);

        pen_account = Double.parseDouble(basic_account_pen);
        usd_account = Double.parseDouble(basic_account_usd);
        pen_trea = Double.parseDouble(basic_account_pen_trea);
        usd_trea = Double.parseDouble(basic_account_usd_trea);
        if (account_currency.equals("PEN"))
        {
            dialog.setTitle("Cuenta Básica Soles (S/ - PEN)");
            dialog.setMessage("Información: ");
            txtBasicAccountAmmount.setText("S/"+basic_account_pen);
            txtTrea.setText(basic_account_pen_trea+"%");
            if (daily_claim_pen_account.equals("true"))
            {
                btnClaimInerest.setText("ESPERA A MAÑANA");
                btnClaimInerest.setEnabled(false);
                btnClaimInerest.setBackgroundResource(R.color.backgroundColor);
                txtInterestAmmount.setText("S/0.00");

            }
            if (daily_claim_pen_account.equals("false"))
            {
                //Calculate daily rate:
                double factor_1 = ((pen_trea/100)+1);
                double daily_rate_pen = Math.pow(factor_1,(0.0027397260273))-1;
                double interest_gained = pen_account*daily_rate_pen;
                String interest_gained_st = decimalFormat.format(interest_gained);
                txtInterestAmmount.setText("S/"+interest_gained_st);
            }
        }



        btnClaimInerest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadingBar.setTitle("Entregando Intereses...");
                loadingBar.setMessage("Cargando...");
                loadingBar.show();
                loadingBar.setCanceledOnTouchOutside(false);
                loadingBar.setCancelable(false);
                //Set min ammount of money in the account
                double min_ammount_pen = Double.parseDouble(min_ammount_pen_account);
                double min_ammount_usd = Double.parseDouble(min_ammount_usd_account);

                HashMap hashMap = new HashMap();

                if (account_currency.equals("PEN"))
                {
                    if (daily_claim_pen_account.equals("false"))
                    {
                        //Calculate daily rate:
                        double factor_1 = ((pen_trea/100)+1);
                        double daily_rate_pen = Math.pow(factor_1,(0.0027397260273))-1;
                        double interest_gained = pen_account*daily_rate_pen;

                        double total_money_pen = interest_gained+pen_account;
                        String total_money_pen_st = decimalFormat.format(total_money_pen);

                        hashMap.put("basic_account_pen",total_money_pen_st);
                        hashMap.put("daily_claim_pen_account", "true");

                        btnClaimInerest.setText("ESPERA A MAÑANA");
                        btnClaimInerest.setEnabled(false);
                        btnClaimInerest.setBackgroundResource(R.color.backgroundColor);
                        txtInterestAmmount.setText("$ 0.00");

                        userRef.child(currentUserID).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {
                                if (task.isSuccessful())
                                {
                                    Toast.makeText(MyAccountActivity.this, "Has cobrado tus intereses exitosamente!", Toast.LENGTH_LONG).show();
                                    loadingBar.dismiss();
                                }
                                else
                                {
                                    String message = task.getException().getMessage();
                                    Toast.makeText(MyAccountActivity.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            }
        });

        dialog.setView(pin_dialog);
        dialog.show();
    }


    private void showRiskRestrictionDialog() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);

        LayoutInflater inflater = LayoutInflater.from(this);
        final View add_bank_account = inflater.inflate(R.layout.restriction_risk_management,null);

        dialog.setView(add_bank_account);

        dialog.setPositiveButton("Entendido", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        dialog.show();
    }

    private void showUserConditionDialog() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);

        LayoutInflater inflater = LayoutInflater.from(this);
        final View add_bank_account = inflater.inflate(R.layout.condition_for_credit_request,null);

        dialog.setView(add_bank_account);

        ImageButton btnStudent,btnDependentWorker,btnIndependentWorker,btnLessor,btnStockHolder;
        btnStudent = add_bank_account.findViewById(R.id.btnStudent);
        btnDependentWorker = add_bank_account.findViewById(R.id.btnDependentWorker);
        btnIndependentWorker = add_bank_account.findViewById(R.id.btnIndependentWorker);
        btnLessor = add_bank_account.findViewById(R.id.btnLessor);
        btnStockHolder = add_bank_account.findViewById(R.id.btnStockHolder);

        btnStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                credit_line_request_condition = "student";
                goToRequestFormActivity();
            }
        });
        btnDependentWorker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                credit_line_request_condition = "dependent_worker";
                goToRequestFormActivity();
            }
        });
        btnIndependentWorker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                credit_line_request_condition = "independent_worker";
                goToRequestFormActivity();
            }
        });
        btnLessor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                credit_line_request_condition = "lessor";
                goToRequestFormActivity();
            }
        });
        btnStockHolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                credit_line_request_condition = "stock_holder";
                goToRequestFormActivity();
            }
        });

        dialog.setPositiveButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        dialog.show();
    }

    private void showRestrictionDialog() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);

        LayoutInflater inflater = LayoutInflater.from(this);
        final View add_bank_account = inflater.inflate(R.layout.restriction_user_verification,null);

        dialog.setPositiveButton("Entendido", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });

        dialog.setView(add_bank_account);
        dialog.show();
    }

    private void goToRequestFormActivity() {
        Intent intent = new Intent(MyAccountActivity.this, CreditLineRequestFormActivity.class);
        intent.putExtra("credit_line_request_currency", credit_line_request_currency);
        intent.putExtra("credit_line_request_condition", credit_line_request_condition);
        startActivity(intent);
    }

    private void loadPaymentMonthUsd() {
        userRef.child(currentUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //Monthly Payments
                credit_line_pen_payment_month1 = dataSnapshot.child("credit_line_usd_payment_month1").getValue().toString();
                credit_line_pen_payment_month2 = dataSnapshot.child("credit_line_usd_payment_month2").getValue().toString();
                credit_line_pen_payment_month3 = dataSnapshot.child("credit_line_usd_payment_month3").getValue().toString();
                credit_line_pen_payment_month4 = dataSnapshot.child("credit_line_usd_payment_month4").getValue().toString();
                credit_line_pen_payment_month5 = dataSnapshot.child("credit_line_usd_payment_month5").getValue().toString();
                credit_line_pen_payment_month6 = dataSnapshot.child("credit_line_usd_payment_month6").getValue().toString();
                credit_line_pen_payment_month7 = dataSnapshot.child("credit_line_usd_payment_month7").getValue().toString();
                credit_line_pen_payment_month8 = dataSnapshot.child("credit_line_usd_payment_month8").getValue().toString();
                credit_line_pen_payment_month9 = dataSnapshot.child("credit_line_usd_payment_month9").getValue().toString();
                credit_line_pen_payment_month10 = dataSnapshot.child("credit_line_usd_payment_month10").getValue().toString();
                credit_line_pen_payment_month11 = dataSnapshot.child("credit_line_usd_payment_month11").getValue().toString();
                credit_line_pen_payment_month12 = dataSnapshot.child("credit_line_usd_payment_month12").getValue().toString();

                credit_line_pen_payment_year1 = dataSnapshot.child("credit_line_usd_payment_year1").getValue(Integer.class);
                credit_line_pen_payment_year2 = dataSnapshot.child("credit_line_usd_payment_year2").getValue(Integer.class);
                credit_line_pen_payment_year3 = dataSnapshot.child("credit_line_usd_payment_year3").getValue(Integer.class);
                credit_line_pen_payment_year4 = dataSnapshot.child("credit_line_usd_payment_year4").getValue(Integer.class);
                credit_line_pen_payment_year5 = dataSnapshot.child("credit_line_usd_payment_year5").getValue(Integer.class);
                credit_line_pen_payment_year6 = dataSnapshot.child("credit_line_usd_payment_year6").getValue(Integer.class);
                credit_line_pen_payment_year7 = dataSnapshot.child("credit_line_usd_payment_year7").getValue(Integer.class);
                credit_line_pen_payment_year8 = dataSnapshot.child("credit_line_usd_payment_year8").getValue(Integer.class);
                credit_line_pen_payment_year9 = dataSnapshot.child("credit_line_usd_payment_year9").getValue(Integer.class);
                credit_line_pen_payment_year10 = dataSnapshot.child("credit_line_usd_payment_year10").getValue(Integer.class);
                credit_line_pen_payment_year11 = dataSnapshot.child("credit_line_usd_payment_year11").getValue(Integer.class);
                credit_line_pen_payment_year12 = dataSnapshot.child("credit_line_usd_payment_year12").getValue(Integer.class);

                credit_line_pen_default_day1 = dataSnapshot.child("credit_line_usd_default_day1").getValue().toString();
                credit_line_pen_default_day2 = dataSnapshot.child("credit_line_usd_default_day2").getValue().toString();
                credit_line_pen_default_day3 = dataSnapshot.child("credit_line_usd_default_day3").getValue().toString();
                credit_line_pen_default_day4 = dataSnapshot.child("credit_line_usd_default_day4").getValue().toString();
                credit_line_pen_default_day5 = dataSnapshot.child("credit_line_usd_default_day5").getValue().toString();
                credit_line_pen_default_day6 = dataSnapshot.child("credit_line_usd_default_day6").getValue().toString();
                credit_line_pen_default_day7 = dataSnapshot.child("credit_line_usd_default_day7").getValue().toString();
                credit_line_pen_default_day8 = dataSnapshot.child("credit_line_usd_default_day8").getValue().toString();
                credit_line_pen_default_day9 = dataSnapshot.child("credit_line_usd_default_day9").getValue().toString();
                credit_line_pen_default_day10 = dataSnapshot.child("credit_line_usd_default_day10").getValue().toString();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        ratesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists())
                {
                    credit_line_start_day_payment = dataSnapshot.child("credit_line_start_day_payment").getValue().toString();
                    credit_line_end_day_payment = dataSnapshot.child("credit_line_end_day_payment").getValue().toString();
                    defaulter_credit_pen_daily_rate= dataSnapshot.child("defaulter_credit_pen_daily_rate").getValue().toString();
                    basic_account_pen_trea = dataSnapshot.child("basic_account_pen_trea").getValue().toString();
                    basic_account_usd_trea = dataSnapshot.child("basic_account_usd_trea").getValue().toString();

                    current_year = Calendar.getInstance().get(Calendar.YEAR);

                    //Date date = new Date();
                    //LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    month =  Calendar.getInstance().get(Calendar.MONTH)+1;
                    day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);

                    credit_month_double1 = Double.parseDouble(credit_line_pen_payment_month1);
                    credit_month_double2 = Double.parseDouble(credit_line_pen_payment_month2);
                    credit_month_double3 = Double.parseDouble(credit_line_pen_payment_month3);
                    credit_month_double4 = Double.parseDouble(credit_line_pen_payment_month4);
                    credit_month_double5 = Double.parseDouble(credit_line_pen_payment_month5);
                    credit_month_double6 = Double.parseDouble(credit_line_pen_payment_month6);
                    credit_month_double7 = Double.parseDouble(credit_line_pen_payment_month7);
                    credit_month_double8 = Double.parseDouble(credit_line_pen_payment_month8);
                    credit_month_double9 = Double.parseDouble(credit_line_pen_payment_month9);
                    credit_month_double10 = Double.parseDouble(credit_line_pen_payment_month10);
                    credit_month_double11 = Double.parseDouble(credit_line_pen_payment_month11);
                    credit_month_double12 = Double.parseDouble(credit_line_pen_payment_month12);

                    defaulter_credit_pen_daily_rate_double = Double.parseDouble(defaulter_credit_pen_daily_rate);

                    start_day = Integer.parseInt(credit_line_start_day_payment);
                    end_day = Integer.parseInt(credit_line_end_day_payment);

                    DecimalFormat decimalFormat = new DecimalFormat("0.00");

                    HashMap hashMap = new HashMap();

                    if (month == 1)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year1 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month1);
                        }
                        if (day > end_day && credit_month_double1 > 0.00 && credit_line_pen_payment_year1 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month1);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*1;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*2;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*3;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*4;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*5;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*6;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*7;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*8;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*9;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*10;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month1",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double2;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month2",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month1","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month1);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month1);
                        }

                    }

                    if (month == 2)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year2 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month2);
                        }
                        if (day > end_day && credit_month_double2 > 0.00 && credit_line_pen_payment_year2 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month3);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*1;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*2;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*3;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*4;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*5;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*6;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*7;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*8;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*9;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*10;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month2",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double3;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month3",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month2","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month2);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month2);
                        }
                    }

                    if (month == 3)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year3 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month3);
                        }
                        if (day > end_day && credit_month_double3 > 0.00 && credit_line_pen_payment_year3 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month3);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*1;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*2;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*3;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*4;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*5;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*6;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*7;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*8;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*9;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*10;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month3",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double4;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month4",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month3","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month3);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month3);
                        }
                    }

                    if (month == 4)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year4 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month4);
                        }
                        if (day > end_day && credit_month_double4 > 0.00 && credit_line_pen_payment_year4 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month4);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*1;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*2;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*3;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*4;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*5;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*6;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*7;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*8;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*9;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*10;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month4",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double5;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month5",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month4","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month4);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month4);
                        }
                    }

                    if (month == 5)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year5 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month5);
                        }
                        if (day > end_day && credit_month_double5 > 0.00 && credit_line_pen_payment_year5 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month5);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*1;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*2;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*3;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*4;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*5;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*6;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*7;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*8;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*9;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*10;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month5",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double6;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month6",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month5","0.00");

                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month5);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month5);
                        }
                    }

                    if (month == 6)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year6 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month6);
                        }
                        if (day > end_day && credit_month_double6 > 0.00 && credit_line_pen_payment_year6 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month6);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*1;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*2;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*3;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*4;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*5;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*6;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*7;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*8;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*9;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*10;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month6",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double7;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month7",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month6","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month6);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month6);
                        }
                    }

                    if (month == 7)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year7 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month7);
                        }
                        if (day > end_day && credit_month_double7 > 0.00 && credit_line_pen_payment_year7 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month7);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*1;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*2;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*3;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*4;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*5;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*6;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*7;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*8;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*9;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*10;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month7",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double8;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month8",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month7","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month7);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month7);
                        }
                    }

                    if (month == 8)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year8 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month8);
                        }
                        if (day > end_day && credit_month_double8 > 0.00 && credit_line_pen_payment_year8 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month8);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*1;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*2;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*3;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*4;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*5;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*6;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*7;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*8;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*9;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*10;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month8",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_usd_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double9;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month9",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month8","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month8);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month8);
                        }
                    }

                    if (month == 9)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year9 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month9);
                        }
                        if (day > end_day && credit_month_double9 > 0.00 && credit_line_pen_payment_year9 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month9);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*1;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*2;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*3;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*4;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*5;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*6;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*7;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*8;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*9;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*10;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month9",new_payment_st);
                                hashMap.put("credit_line_usd_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double10;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month10",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month9","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month9);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month9);
                        }
                    }

                    if (month == 10)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year10 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month10);
                        }
                        if (day > end_day && credit_month_double10 > 0.00 && credit_line_pen_payment_year10 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month10);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*1;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*2;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*3;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*4;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*5;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*6;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*7;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*8;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*9;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*10;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month10",new_payment_st);
                                hashMap.put("credit_line_usd_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double11;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month11",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month10","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month10);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month10);
                        }

                    }

                    if (month == 11)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year11 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month11);
                        }
                        if (day > end_day && credit_month_double11 > 0.00 && credit_line_pen_payment_year11 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month11);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*1;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*2;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*3;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*4;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*5;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*6;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*7;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*8;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*9;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*10;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month11",new_payment_st);
                                hashMap.put("credit_line_usd_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double12;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month12",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month11","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month11);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month11);
                        }
                    }

                    if (month == 12)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year12 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month12);
                        }
                        if (day > end_day && credit_month_double12 > 0.00 && credit_line_pen_payment_year12 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month12);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*1;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*2;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*3;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*4;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*5;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*6;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*7;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*8;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*9;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*10;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_usd_payment_month12",new_payment_st);
                                hashMap.put("credit_line_usd_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double1;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_usd_payment_month1",quotes_acomulated_st);
                                hashMap.put("credit_line_usd_payment_month12","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: $ "+credit_line_pen_payment_month12);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month12);
                        }
                    }

                    userRef.child(currentUserID).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void loadPaymentMonthPen() {
        ratesRef.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists())
                {
                    credit_line_start_day_payment = dataSnapshot.child("credit_line_start_day_payment").getValue().toString();
                    credit_line_end_day_payment = dataSnapshot.child("credit_line_end_day_payment").getValue().toString();
                    defaulter_credit_pen_daily_rate= dataSnapshot.child("defaulter_credit_pen_daily_rate").getValue().toString();
                    min_ammount_pen_account = dataSnapshot.child("min_ammount_pen_account").getValue().toString();
                    min_ammount_usd_account = dataSnapshot.child("min_ammount_usd_account").getValue().toString();


                    current_year = Calendar.getInstance().get(Calendar.YEAR);

                    month =  Calendar.getInstance().get(Calendar.MONTH)+1;
                    day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);

                    credit_month_double1 = Double.parseDouble(credit_line_pen_payment_month1);
                    credit_month_double2 = Double.parseDouble(credit_line_pen_payment_month2);
                    credit_month_double3 = Double.parseDouble(credit_line_pen_payment_month3);
                    credit_month_double4 = Double.parseDouble(credit_line_pen_payment_month4);
                    credit_month_double5 = Double.parseDouble(credit_line_pen_payment_month5);
                    credit_month_double6 = Double.parseDouble(credit_line_pen_payment_month6);
                    credit_month_double7 = Double.parseDouble(credit_line_pen_payment_month7);
                    credit_month_double8 = Double.parseDouble(credit_line_pen_payment_month8);
                    credit_month_double9 = Double.parseDouble(credit_line_pen_payment_month9);
                    credit_month_double10 = Double.parseDouble(credit_line_pen_payment_month10);
                    credit_month_double11 = Double.parseDouble(credit_line_pen_payment_month11);
                    credit_month_double12 = Double.parseDouble(credit_line_pen_payment_month12);

                    defaulter_credit_pen_daily_rate_double = Double.parseDouble(defaulter_credit_pen_daily_rate);

                    start_day = Integer.parseInt(credit_line_start_day_payment);
                    end_day = Integer.parseInt(credit_line_end_day_payment);


                    DecimalFormat decimalFormat = new DecimalFormat("0.00");

                    HashMap hashMap = new HashMap();

                    if (month == 1)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year1 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month1);
                        }
                        if (day > end_day && credit_month_double1 >= 0.00 && credit_line_pen_payment_year1 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month1);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*1;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*2;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*3;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*4;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*5;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*6;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*7;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*8;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*9;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*10;
                                new_payment = credit_month_double1+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month1",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double2;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month2",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month1","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month1);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month1);
                        }

                    }

                    if (month == 2)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year2 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month2);
                        }
                        if (day > end_day && credit_month_double2 >= 0.00 && credit_line_pen_payment_year2 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month3);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double1))*1;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*2;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*3;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*4;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*5;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*6;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*7;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*8;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*9;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double2))*10;
                                new_payment = credit_month_double2+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month2",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double3;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month3",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month2","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month2);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month2);
                        }
                    }

                    if (month == 3)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year3 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month3);
                        }
                        if (day > end_day && credit_month_double3 >= 0.00 && credit_line_pen_payment_year3 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month3);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*1;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*2;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*3;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*4;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*5;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*6;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*7;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*8;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*9;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double3))*10;
                                new_payment = credit_month_double3+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month3",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double4;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month4",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month3","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month3);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month3);
                        }
                    }

                    if (month == 4)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year4 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month4);
                        }
                        if (day > end_day && credit_month_double4 >= 0.00 && credit_line_pen_payment_year4 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month4);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*1;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*2;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*3;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*4;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*5;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*6;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*7;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*8;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*9;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double4))*10;
                                new_payment = credit_month_double4+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month4",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double5;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month5",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month4","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month4);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month4);
                        }
                    }

                    if (month == 5)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year5 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month5);
                        }
                        if (day > end_day && credit_month_double5 >= 0.00 && credit_line_pen_payment_year5 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month5);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*1;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*2;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*3;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*4;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*5;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*6;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*7;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*8;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*9;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double5))*10;
                                new_payment = credit_month_double5+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month5",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double6;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month6",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month5","0.00");

                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month5);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month5);
                        }
                    }

                    if (month == 6)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year6 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month6);
                        }
                        if (day > end_day && credit_month_double6 >= 0.00 && credit_line_pen_payment_year6 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month6);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*1;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*2;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*3;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*4;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*5;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*6;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*7;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*8;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*9;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double6))*10;
                                new_payment = credit_month_double6+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month6",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double7;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month7",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month6","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month6);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month6);
                        }
                    }

                    if (month == 7)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year7 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month7);
                        }
                        if (day > end_day && credit_month_double8 >= 0.00 && credit_line_pen_payment_year7 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month7);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*1;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*2;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*3;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*4;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*5;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*6;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*7;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*8;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*9;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double7))*10;
                                new_payment = credit_month_double7+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month7",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double8;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month8",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month7","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month7);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month7);
                        }
                    }

                    if (month == 8)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year8 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month8);
                        }
                        if (day > end_day && credit_month_double8 >= 0.00 && credit_line_pen_payment_year8 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month8);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*1;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*2;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*3;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*4;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*5;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*6;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*7;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*8;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*9;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double8))*10;
                                new_payment = credit_month_double8+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month8",new_payment_st);
                                hashMap.put("user_is_defaulter","true");
                                hashMap.put("credit_line_pen_default_day10","true");
                                //This quite is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double9;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month9",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month8","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month8);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month8);
                        }
                    }

                    if (month == 9)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year9 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month9);
                        }
                        if (day > end_day && credit_month_double9 >= 0.00 && credit_line_pen_payment_year9 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month9);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*1;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*2;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*3;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*4;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*5;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*6;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*7;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*8;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*9;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double9))*10;
                                new_payment = credit_month_double9+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month9",new_payment_st);
                                hashMap.put("credit_line_pen_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double10;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month10",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month9","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month9);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month9);
                        }
                    }

                    if (month == 10)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year10 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month10);
                        }
                        if (day > end_day && credit_month_double10 >= 0.00 && credit_line_pen_payment_year10 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month10);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*1;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*2;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*3;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*4;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*5;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*6;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*7;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*8;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*9;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double10))*10;
                                new_payment = credit_month_double10+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month10",new_payment_st);
                                hashMap.put("credit_line_pen_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double11;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month11",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month10","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month10);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month10);
                        }

                    }

                    if (month == 11)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year11 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month11);
                        }
                        if (day > end_day && credit_month_double11 >= 0.00 && credit_line_pen_payment_year11 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month11);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*1;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*2;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*3;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*4;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*5;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*6;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*7;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*8;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*9;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double11))*10;
                                new_payment = credit_month_double11+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month11",new_payment_st);
                                hashMap.put("credit_line_pen_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double12;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month12",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month11","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month11);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month11);
                        }
                    }

                    if (month == 12)
                    {
                        if (day >= start_day && day <= end_day && credit_line_pen_payment_year12 == current_year)
                        {
                            //Customer should pay in these days
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month12);
                        }
                        if (day > end_day && credit_month_double12 >= 0.00 && credit_line_pen_payment_year12 == current_year)
                        {
                            txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month12);
                            //Customer didn't pay on time
                            if (day == end_day+1 && credit_line_pen_default_day1.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*1;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day1","true");
                            }
                            if (day == end_day+2 && credit_line_pen_default_day2.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*2;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day2","true");
                            }
                            if (day == end_day+3 && credit_line_pen_default_day3.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*3;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day3","true");
                            }
                            if (day == end_day+4 && credit_line_pen_default_day4.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*4;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day4","true");
                            }
                            if (day == end_day+5 && credit_line_pen_default_day5.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*5;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day5","true");
                            }
                            if (day == end_day+6 && credit_line_pen_default_day6.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*6;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day6","true");
                            }
                            if (day == end_day+7 && credit_line_pen_default_day7.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*7;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day7","true");
                            }
                            if (day == end_day+8 && credit_line_pen_default_day8.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*8;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day8","true");
                            }
                            if (day == end_day+9 && credit_line_pen_default_day9.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*9;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day9","true");
                            }
                            if (day == end_day+10 && credit_line_pen_default_day10.equals("false"))
                            {
                                defaulter_rate = (((defaulter_credit_pen_daily_rate_double/100)*credit_month_double12))*10;
                                new_payment = credit_month_double12+defaulter_rate;
                                new_payment_st = decimalFormat.format(new_payment);
                                hashMap.put("credit_line_pen_payment_month12",new_payment_st);
                                hashMap.put("credit_line_pen_default_day10","true");
                                hashMap.put("user_is_defaulter","true");
                                //This quote is for the next month: debt + next quote
                                quotes_acomulated = new_payment+credit_month_double1;
                                quotes_acomulated_st = decimalFormat.format(quotes_acomulated);
                                hashMap.put("credit_line_pen_payment_month1",quotes_acomulated_st);
                                hashMap.put("credit_line_pen_payment_month12","0.00");
                            }
                            else
                            {
                                //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ 0.00");
                                txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month12);
                            }

                            //txtCreditLinePaymentMonthPen.setText("PAGO DEL MES: S/ "+credit_line_pen_payment_month12);
                        }
                    }


                    userRef.child(currentUserID).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            loadingBar.dismiss();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
