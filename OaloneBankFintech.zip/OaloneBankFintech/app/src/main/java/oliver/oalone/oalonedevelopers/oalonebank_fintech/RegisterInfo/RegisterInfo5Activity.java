package oliver.oalone.oalonedevelopers.oalonebank_fintech.RegisterInfo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.zxing.WriterException;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;

import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;
import androidmads.library.qrgenearator.QRGSaver;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.MainActivity;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.R;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.RegisterInfoActivity;

public class RegisterInfo5Activity extends AppCompatActivity {

    EditText edtUsername,edtPin,edtConfirmPin;
    CheckBox checkDataTrue,checkDataManagement;
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;
    String currentUserID;
    String saveCurrentDate,saveCurrentTime,postRandomName,phoneNumber;
    String userVerification = "progress", username_exist;
    RelativeLayout rootLayout;
    Button btnRegister;
    private StorageReference userProfileImageRef;
    private ProgressDialog loadingBar;
    String TAG = "GenerateQRCode",downloadUrlQr;
    ImageView qrCode;
    String edtValue;
    String inputValue;
    String savePath = Environment.getExternalStorageDirectory().getPath() + "/QRCode/";
    Bitmap bitmap;
    QRGEncoder qrgEncoder;
    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_info5);

        edtUsername = findViewById(R.id.edtUsername);
        edtPin = findViewById(R.id.edtPin);
        edtConfirmPin = findViewById(R.id.edtConfirmPin);
        checkDataTrue = findViewById(R.id.checkDataTrue);
        checkDataManagement = findViewById(R.id.checkDataManagement);
        rootLayout = findViewById(R.id.rootLayout);
        btnRegister = findViewById(R.id.btnRegister);
        qrCode = findViewById(R.id.qrCode);
        loadingBar = new ProgressDialog(this);
        username_exist = "false";

        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();
        userRef = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID);
        userProfileImageRef = FirebaseStorage.getInstance().getReference().child("Profile Images");
        phoneNumber = mAuth.getCurrentUser().getPhoneNumber();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(edtUsername.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Debes ingresar un nombre de usuario", Snackbar.LENGTH_LONG).show();
                    return;
                }
                else
                {
                    Query query1 =  userRef.orderByChild("username").equalTo(edtUsername.getText().toString());
                    query1.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            for (DataSnapshot id : dataSnapshot.getChildren()) {
                                String user_id = id.getKey();
                                userRef.child(Objects.requireNonNull(user_id)).child("username").addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        if(Objects.requireNonNull(dataSnapshot.getValue()).toString().equals(edtUsername.getText().toString())){
                                            username_exist = "true";

                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
                if (username_exist.equals("true")) {
                    Snackbar.make(rootLayout, "El nombre de usuario "+edtUsername.getText().toString()+" ya existe, debes crear otro.", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (TextUtils.isEmpty(edtPin.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Debes ingresar tu PIN de seguridad", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (TextUtils.isEmpty(edtConfirmPin.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Debes confirmar tu PIN de seguridad", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (edtPin.getText().toString().length() != 4)
                {
                    Snackbar.make(rootLayout, "Tu PIN debe ser de 4 dígitos", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (!edtPin.getText().toString().equals(edtConfirmPin.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Los PIN de seguridad no coinciden", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (!checkDataTrue.isChecked())
                {
                    Snackbar.make(rootLayout, "Debes confirmar que la información proporcionada es correcta y verdadera", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (!checkDataManagement.isChecked()) {
                    Snackbar.make(rootLayout, "Debes confirmar que estás de acuerdo con las políticas, términos y condiciones", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (!checkDataManagement.isChecked()) {
                    Snackbar.make(rootLayout, "Debes confirmar que estás de acuerdo con las políticas, términos y condiciones", Snackbar.LENGTH_LONG).show();
                    return;
                }else {

                    loadingBar.setTitle("Preparando todo...");
                    loadingBar.setMessage("Cargando...");
                    loadingBar.show();
                    loadingBar.setCanceledOnTouchOutside(false);
                    loadingBar.setCancelable(false);

                    Calendar calForDate = Calendar.getInstance();
                    SimpleDateFormat currentDate = new SimpleDateFormat("dd-MM-yyyy");
                    saveCurrentDate =currentDate.format(calForDate.getTime());

                    Calendar calForTime = Calendar.getInstance();
                    SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss");
                    saveCurrentTime =currentTime.format(calForTime.getTime());

                    generateQrCode();
                    saveQrCode();
                    sendQrCodeToDatabase();

                }
            }
        });
    }

    private void sendQrCodeToDatabase() {

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(RegisterInfo5Activity.this.getContentResolver(), bitmap, "Title", null);
        uri = Uri.parse(path);

        StorageReference filePath = userProfileImageRef.child(uri.getLastPathSegment()+postRandomName+".jpg");
        filePath.putFile(uri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                if (task.isSuccessful()) {
                    downloadUrlQr = task.getResult().getDownloadUrl().toString();

                    HashMap userMap = new HashMap();
                    userMap.put("username",edtUsername.getText().toString().toLowerCase());
                    userMap.put("user_verification",userVerification);
                    userMap.put("pin",edtPin.getText().toString());
                    userMap.put("document_verification","none");
                    userMap.put("basic_account_pen","0.00");
                    userMap.put("basic_account_usd","0.00");
                    userMap.put("state","offline");
                    userMap.put("credit_line_pen","false");
                    userMap.put("credit_line_pen_available","0.00");
                    userMap.put("credit_line_pen_default_day1","false");
                    userMap.put("credit_line_pen_default_day2","false");
                    userMap.put("credit_line_pen_default_day3","false");
                    userMap.put("credit_line_pen_default_day4","false");
                    userMap.put("credit_line_pen_default_day5","false");
                    userMap.put("credit_line_pen_default_day6","false");
                    userMap.put("credit_line_pen_default_day7","false");
                    userMap.put("credit_line_pen_default_day8","false");
                    userMap.put("credit_line_pen_default_day9","false");
                    userMap.put("credit_line_pen_default_day10","false");
                    userMap.put("credit_line_pen_payment_month1","0.00");
                    userMap.put("credit_line_pen_payment_month2","0.00");
                    userMap.put("credit_line_pen_payment_month3","0.00");
                    userMap.put("credit_line_pen_payment_month4","0.00");
                    userMap.put("credit_line_pen_payment_month5","0.00");
                    userMap.put("credit_line_pen_payment_month6","0.00");
                    userMap.put("credit_line_pen_payment_month7","0.00");
                    userMap.put("credit_line_pen_payment_month8","0.00");
                    userMap.put("credit_line_pen_payment_month9","0.00");
                    userMap.put("credit_line_pen_payment_month10","0.00");
                    userMap.put("credit_line_pen_payment_month11","0.00");
                    userMap.put("credit_line_pen_payment_month12","0.00");
                    userMap.put("credit_line_pen_tcea","800.00");
                    userMap.put("credit_line_pen_total","0.00");
                    userMap.put("credit_line_pen_used","0.00");
                    userMap.put("credit_line_pen_was_used","false");
                    userMap.put("credit_line_usd","false");
                    userMap.put("credit_line_usd_available","0.00");
                    userMap.put("credit_line_usd_default_day1","false");
                    userMap.put("credit_line_usd_default_day2","false");
                    userMap.put("credit_line_usd_default_day3","false");
                    userMap.put("credit_line_usd_default_day4","false");
                    userMap.put("credit_line_usd_default_day5","false");
                    userMap.put("credit_line_usd_default_day6","false");
                    userMap.put("credit_line_usd_default_day7","false");
                    userMap.put("credit_line_usd_default_day8","false");
                    userMap.put("credit_line_usd_default_day9","false");
                    userMap.put("credit_line_usd_default_day10","false");
                    userMap.put("credit_line_usd_payment_month1","0.00");
                    userMap.put("credit_line_usd_payment_month2","0.00");
                    userMap.put("credit_line_usd_payment_month3","0.00");
                    userMap.put("credit_line_usd_payment_month4","0.00");
                    userMap.put("credit_line_usd_payment_month5","0.00");
                    userMap.put("credit_line_usd_payment_month6","0.00");
                    userMap.put("credit_line_usd_payment_month7","0.00");
                    userMap.put("credit_line_usd_payment_month8","0.00");
                    userMap.put("credit_line_usd_payment_month9","0.00");
                    userMap.put("credit_line_usd_payment_month10","0.00");
                    userMap.put("credit_line_usd_payment_month11","0.00");
                    userMap.put("credit_line_usd_payment_month12","0.00");
                    userMap.put("credit_line_pen_payment_year1",0);
                    userMap.put("credit_line_pen_payment_year2",0);
                    userMap.put("credit_line_pen_payment_year3",0);
                    userMap.put("credit_line_pen_payment_year4",0);
                    userMap.put("credit_line_pen_payment_year5",0);
                    userMap.put("credit_line_pen_payment_year6",0);
                    userMap.put("credit_line_pen_payment_year7",0);
                    userMap.put("credit_line_pen_payment_year8",0);
                    userMap.put("credit_line_pen_payment_year9",0);
                    userMap.put("credit_line_pen_payment_year10",0);
                    userMap.put("credit_line_pen_payment_year11",0);
                    userMap.put("credit_line_pen_payment_year12",0);
                    userMap.put("credit_line_usd_payment_year1",0);
                    userMap.put("credit_line_usd_payment_year2",0);
                    userMap.put("credit_line_usd_payment_year3",0);
                    userMap.put("credit_line_usd_payment_year4",0);
                    userMap.put("credit_line_usd_payment_year5",0);
                    userMap.put("credit_line_usd_payment_year6",0);
                    userMap.put("credit_line_usd_payment_year7",0);
                    userMap.put("credit_line_usd_payment_year8",0);
                    userMap.put("credit_line_usd_payment_year9",0);
                    userMap.put("credit_line_usd_payment_year10",0);
                    userMap.put("credit_line_usd_payment_year11",0);
                    userMap.put("credit_line_usd_payment_year12",0);
                    userMap.put("credit_line_usd_tcea","800.00");
                    userMap.put("credit_line_usd_total","0.00");
                    userMap.put("credit_line_usd_used","0.00");
                    userMap.put("credit_line_usd_was_used","false");
                    userMap.put("credit_risk_param","0.00");
                    userMap.put("credit_score","5");
                    userMap.put("credit_line_pen_request_state","false");
                    userMap.put("credit_line_usd_request_state","false");
                    userMap.put("qr_code_image",downloadUrlQr);

                    userMap.put("daily_claim_pen_account","false");
                    userMap.put("daily_claim_usd_account","false");
                    userMap.put("pen_accoount_is_enabled","true");
                    userMap.put("usd_accoount_is_enabled","true");

                    userMap.put("user_is_enabled","true");

                    userMap.put("phone_number",phoneNumber);

                    userMap.put("register_date",saveCurrentDate);
                    userMap.put("register_time",saveCurrentTime);

                    userRef.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()) {
                                Intent intent = new Intent(RegisterInfo5Activity.this, MainActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                loadingBar.dismiss();
                                startActivity(intent);
                                finish();
                            }
                            else
                            {
                                String message = task.getException().getMessage();
                                Toast.makeText(RegisterInfo5Activity.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();

                            }
                        }
                    });

                }
            }
        });

    }

    private void saveQrCode() {
        boolean save;
        String result;
        try {
            save = QRGSaver.save(savePath, postRandomName.trim(), bitmap, QRGContents.ImageType.IMAGE_JPEG);
            result = save ? "Image Saved" : "Image Not Saved";
            //Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void generateQrCode() {
        inputValue = currentUserID;
        if (inputValue.length() > 0) {
            WindowManager manager = (WindowManager) getSystemService(WINDOW_SERVICE);
            Display display = manager.getDefaultDisplay();
            Point point = new Point();
            display.getSize(point);
            int width = point.x;
            int height = point.y;
            int smallerDimension = width < height ? width : height;
            smallerDimension = smallerDimension * 3 / 4;

            qrgEncoder = new QRGEncoder(
                    inputValue, null,
                    QRGContents.Type.TEXT,
                    smallerDimension);
            try {
                bitmap = qrgEncoder.encodeAsBitmap();
                qrCode.setImageBitmap(bitmap);
            } catch (WriterException e) {
                Log.v(TAG, e.toString());
            }
        } else {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }
}
