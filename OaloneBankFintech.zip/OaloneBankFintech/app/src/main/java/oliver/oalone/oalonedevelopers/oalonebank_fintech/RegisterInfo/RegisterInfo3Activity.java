package oliver.oalone.oalonedevelopers.oalonebank_fintech.RegisterInfo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;

import in.galaxyofandroid.spinerdialog.OnSpinerItemClick;
import in.galaxyofandroid.spinerdialog.SpinnerDialog;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.R;
import oliver.oalone.oalonedevelopers.oalonebank_fintech.RegisterInfoActivity;

public class RegisterInfo3Activity extends AppCompatActivity {

    EditText edtEmail,edtAddress;
    Button btnDepartment,btnDistrict,btnProvince,btnNext;
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;
    String currentUserID;
    private RelativeLayout rootLayout;
    private ProgressDialog loadingBar;


    ArrayList<String> department =new ArrayList<>();
    SpinnerDialog spinnerDepartment;

    ArrayList<String> province =new ArrayList<>();
    SpinnerDialog spinnerprovince;

    ArrayList<String> provinceCallao =new ArrayList<>();
    SpinnerDialog spinnerprovinceCallao;

    ArrayList<String> district_list =new ArrayList<>();
    SpinnerDialog spinnerdistrict_list;

    ArrayList<String> district_listBarranca =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listBarranca;

    ArrayList<String> district_listCajatambo =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listCajatambo;

    ArrayList<String> district_listCañete =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listCañete;

    ArrayList<String> district_listCanta =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listCanta;

    ArrayList<String> district_listHuaral =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listHuaral;

    ArrayList<String> district_listHuarochirí =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listHuarochirí;

    ArrayList<String> district_listHuaura =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listHuaura;

    ArrayList<String> district_listOyon =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listOyon;

    ArrayList<String> district_listYauyos =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listYauyos;

    ArrayList<String> district_listCallao =new ArrayList<>();
    SpinnerDialog spinnerdistrict_listCallao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_info3);

        edtEmail = findViewById(R.id.edtEmail);
        edtAddress = findViewById(R.id.edtAddress);
        btnDepartment = findViewById(R.id.btnDepartment);
        btnProvince = findViewById(R.id.btnProvince);
        btnDistrict = findViewById(R.id.btnDistrict);
        rootLayout = findViewById(R.id.rootLayout);
        btnNext = findViewById(R.id.btnNext);
        loadingBar = new ProgressDialog(this);

        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();
        userRef = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID);

        department.add("Lima");department.add("Callao");

        btnDepartment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spinnerDepartment.showSpinerDialog();
            }
        });

        spinnerDepartment = new SpinnerDialog(RegisterInfo3Activity.this,department,"Selecciona tu Departamento");
        spinnerDepartment.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDepartment.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        province.add("Lima");province.add("Barranca");province.add("Cajatambo");province.add("Cañete");province.add("Canta");province.add("Huaral");province.add("Huarochirí");
        province.add("Huaura");province.add("Oyón");province.add("Yauyos");

        provinceCallao.add("Callao");

        btnProvince.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnDistrict.setText("");
                if (btnDepartment.getText().toString().equals("Lima"))
                {
                    spinnerprovince.showSpinerDialog();
                }
                if (btnDepartment.getText().toString().equals("Callao"))
                {
                    spinnerprovinceCallao.showSpinerDialog();
                }
                else
                {
                    Snackbar.make(rootLayout, "Debes seleccionar un departamento primero", Snackbar.LENGTH_LONG).show();
                    return;
                }

            }
        });

        spinnerprovince = new SpinnerDialog(RegisterInfo3Activity.this,province,"Selecciona tu Provincia");
        spinnerprovince.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnProvince.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerprovinceCallao = new SpinnerDialog(RegisterInfo3Activity.this,provinceCallao,"Selecciona tu Provincia");
        spinnerprovinceCallao.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnProvince.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        district_list.add("Ancón");district_list.add("Ate");district_list.add("Barranco");district_list.add("Breña");district_list.add("Carabayllo");
        district_list.add("Chaclacayo");district_list.add("Chorrillos");district_list.add("Cieneguilla");district_list.add("Comas");
        district_list.add("El Agustino");district_list.add("Independencia");district_list.add("Jesús María");district_list.add("La Molina");
        district_list.add("La Victoria");district_list.add("Lima");district_list.add("Lince");district_list.add("Los Olivos");
        district_list.add("Lurigancho");district_list.add("Lurín");district_list.add("Magdalena del Mar");district_list.add("Miraflores");
        district_list.add("Pachacamac");district_list.add("Pucusana");district_list.add("Pueblo Libre");district_list.add("Puente Piedra");
        district_list.add("Punta Hermosa");district_list.add("Punta Negra");district_list.add("Rímac");district_list.add("San Bartolo");
        district_list.add("San Borja");district_list.add("San Isidro");district_list.add("San Juan de Lurigancho");district_list.add("San Juan de Miraflores");
        district_list.add("San Luis");district_list.add("San Martín de Porres");district_list.add("San Miguel");district_list.add("Santa Anita");
        district_list.add("Santa Rosa");district_list.add("Santiago de Surco");district_list.add("Surquillo");district_list.add("Villa El Salvador");
        district_list.add("Villa María del Triunfo");

        district_listBarranca.add("Barranca");district_listBarranca.add("Paramonga");district_listBarranca.add("Pativilca");district_listBarranca.add("Supe");
        district_listBarranca.add("Supe Puerto");

        district_listCajatambo.add("Cajatambo");district_listCajatambo.add("Copa");district_listCajatambo.add("Gorgor");
        district_listCajatambo.add("Huancapón");district_listCajatambo.add("Manás");

        district_listCañete.add("Asia");district_listCañete.add("Calango");district_listCañete.add("Cerro Azul");district_listCañete.add("Chilca");
        district_listCañete.add("Coayllo");district_listCañete.add("Imperial");district_listCañete.add("Lunahuaná");district_listCañete.add("Mala");
        district_listCañete.add("Nuevo Imperial");district_listCañete.add("Pacarán");district_listCañete.add("Quilmaná");district_listCañete.add("San Antonio");
        district_listCañete.add("San Luis");district_listCañete.add("San Vicente de Cañete");district_listCañete.add("Santa Cruz de Flores");

        district_listCanta.add("Arahuay"); district_listCanta.add("Canta"); district_listCanta.add("Huamatanga"); district_listCanta.add("Huaros");
        district_listCanta.add("Lachaqui");district_listCanta.add("San Buenaventura"); district_listCanta.add("Santa Rosa de Quives");

        district_listHuaral.add("Atavillos Alto");district_listHuaral.add("Atavillos Bajo");district_listHuaral.add("Aucallama");district_listHuaral.add("Chancay");
        district_listHuaral.add("Huaral");district_listHuaral.add("Ihuarí");district_listHuaral.add("Lampián");district_listHuaral.add("Pacaraos");
        district_listHuaral.add("San Miguel de Acos");district_listHuaral.add("Santa Cruz de Andamarca");district_listHuaral.add("Sumbilca");
        district_listHuaral.add("Veintisiete de Noviembre");

        district_listHuarochirí.add("Antioquía"); district_listHuarochirí.add("Callahuanca"); district_listHuarochirí.add("Carampoma"); district_listHuarochirí.add("Chicla");
        district_listHuarochirí.add("Cuenca");district_listHuarochirí.add("Huachupampa"); district_listHuarochirí.add("Huanza"); district_listHuarochirí.add("Huarochirí");
        district_listHuarochirí.add("Lahuaytambo");district_listHuarochirí.add("Langa");district_listHuarochirí.add("Mariatana"); district_listHuarochirí.add("Matucana");
        district_listHuarochirí.add("Ricardo Palma");district_listHuarochirí.add("San Andrés de Tupicocha"); district_listHuarochirí.add("San Antonio de Chaclla");
        district_listHuarochirí.add("San Bartolomé"); district_listHuarochirí.add("San Damián"); district_listHuarochirí.add("San Juan de Iris");
        district_listHuarochirí.add("San Juan de Tantaranche"); district_listHuarochirí.add("San Lorenzo de Quinti");district_listHuarochirí.add("San Mateo");
        district_listHuarochirí.add("San Mateo de Otao"); district_listHuarochirí.add("San Pedro de Casta");district_listHuarochirí.add("San Pedro de Huancayre");
        district_listHuarochirí.add("Sangallaya");district_listHuarochirí.add("Santa Cruz de Cocachacra"); district_listHuarochirí.add("Santa Eulalia");
        district_listHuarochirí.add("Santiago de Anchucaya");district_listHuarochirí.add("Santiago de Tuna"); district_listHuarochirí.add("Santo Domingo de los Olleros");
        district_listHuarochirí.add("Surco");

        district_listHuaura.add("Ámbar");district_listHuaura.add("Caleta de Carquín");district_listHuaura.add("Checras");
        district_listHuaura.add("Huacho");district_listHuaura.add("Hualmay");district_listHuaura.add("Huaura");district_listHuaura.add("Leoncio Prado");
        district_listHuaura.add("Paccho");district_listHuaura.add("Santa Leonor");district_listHuaura.add("Santa María");district_listHuaura.add("Sayán");
        district_listHuaura.add("Végueta");

        district_listOyon.add("Andajes"); district_listOyon.add("Caujul"); district_listOyon.add("Cochamarca"); district_listOyon.add("Naván");
        district_listOyon.add("Oyón"); district_listOyon.add("Pachangara");

        district_listYauyos.add("Alis");district_listYauyos.add("Ayauca");district_listYauyos.add("Ayaviri");district_listYauyos.add("Azángaro");district_listYauyos.add("Cacra");
        district_listYauyos.add("Carania");district_listYauyos.add("Catahuasi");district_listYauyos.add("Chocos");district_listYauyos.add("Cochas");district_listYauyos.add("Colonia");
        district_listYauyos.add("Hongos");district_listYauyos.add("Huampará");district_listYauyos.add("Huancaya");district_listYauyos.add("Huangáscar");district_listYauyos.add("Huañec");
        district_listYauyos.add("Huantán");district_listYauyos.add("Laraos");district_listYauyos.add("Lincha");district_listYauyos.add("Madeán");district_listYauyos.add("Miraflores");
        district_listYauyos.add("Omas");district_listYauyos.add("Putinza");district_listYauyos.add("Quinches");district_listYauyos.add("Quinocay");district_listYauyos.add("San Joaquín");
        district_listYauyos.add("San Pedro de Pilas");district_listYauyos.add("Tanta");district_listYauyos.add("Tauripampa");district_listYauyos.add("Tomas");district_listYauyos.add("Tupe");
        district_listYauyos.add("Viñac");district_listYauyos.add("Vitis");district_listYauyos.add("Yauyos");

        district_listCallao.add("Bellavista");district_listCallao.add("Callao");district_listCallao.add("Carmen de La Legua-Reynoso");district_listCallao.add("La Perla");
        district_listCallao.add("La Punta");district_listCallao.add("Mi Perú");district_listCallao.add("Ventanilla");

        btnDistrict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btnProvince.getText().toString().equals("Lima"))
                {
                    spinnerdistrict_list.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Barranca"))
                {
                    spinnerdistrict_listBarranca.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Cajatambo"))
                {
                    spinnerdistrict_listCajatambo.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Cañete"))
                {
                    spinnerdistrict_listCañete.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Canta"))
                {
                    spinnerdistrict_listCanta.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Huaral"))
                {
                    spinnerdistrict_listHuaral.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Huarochirí"))
                {
                    spinnerdistrict_listHuarochirí.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Huaura"))
                {
                    spinnerdistrict_listHuarochirí.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Oyón"))
                {
                    spinnerdistrict_listOyon.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Yauyos"))
                {
                    spinnerdistrict_listYauyos.showSpinerDialog();
                }
                if (btnProvince.getText().toString().equals("Callao"))
                {
                    spinnerdistrict_listCallao.showSpinerDialog();
                }
                if (TextUtils.isEmpty(btnProvince.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Debes seleccionar una provincia primero", Snackbar.LENGTH_LONG).show();
                    return;
                }
            }
        });

        spinnerdistrict_list = new SpinnerDialog(RegisterInfo3Activity.this,district_list,"Selecciona tu Distrito");
        spinnerdistrict_list.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listBarranca = new SpinnerDialog(RegisterInfo3Activity.this,district_listBarranca,"Selecciona tu Distrito");
        spinnerdistrict_listBarranca.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listCajatambo = new SpinnerDialog(RegisterInfo3Activity.this,district_listCajatambo,"Selecciona tu Distrito");
        spinnerdistrict_listCajatambo.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listCañete = new SpinnerDialog(RegisterInfo3Activity.this,district_listCañete,"Selecciona tu Distrito");
        spinnerdistrict_listCañete.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listCanta = new SpinnerDialog(RegisterInfo3Activity.this,district_listCanta,"Selecciona tu Distrito");
        spinnerdistrict_listCanta.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listHuaral = new SpinnerDialog(RegisterInfo3Activity.this,district_listHuaral,"Selecciona tu Distrito");
        spinnerdistrict_listHuaral.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listHuarochirí = new SpinnerDialog(RegisterInfo3Activity.this,district_listHuarochirí,"Selecciona tu Distrito");
        spinnerdistrict_listHuarochirí.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listHuaura = new SpinnerDialog(RegisterInfo3Activity.this,district_listHuaura,"Selecciona tu Distrito");
        spinnerdistrict_listHuaura.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listOyon = new SpinnerDialog(RegisterInfo3Activity.this,district_listOyon,"Selecciona tu Distrito");
        spinnerdistrict_listOyon.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listYauyos = new SpinnerDialog(RegisterInfo3Activity.this,district_listYauyos,"Selecciona tu Distrito");
        spinnerdistrict_listYauyos.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        spinnerdistrict_listCallao = new SpinnerDialog(RegisterInfo3Activity.this,district_listCallao,"Selecciona tu Distrito");
        spinnerdistrict_listCallao.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                btnDistrict.setText(item);
                Toast.makeText(RegisterInfo3Activity.this, "Seleccionado: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(edtEmail.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Debes ingresar tu correo electrónico", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (TextUtils.isEmpty(btnDepartment.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Debes seleccionar el departamento donde vives", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (TextUtils.isEmpty(btnDistrict.getText().toString()))
                {
                    Snackbar.make(rootLayout, "Debes seleccionar el distrito donde vives", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (TextUtils.isEmpty(edtAddress.getText().toString())) {
                    Snackbar.make(rootLayout, "Debes ingresar tu dirección exacta", Snackbar.LENGTH_LONG).show();
                    return;
                }
                if (TextUtils.isEmpty(edtAddress.getText().toString())) {
                    Snackbar.make(rootLayout, "Debes ingresar tu dirección exacta", Snackbar.LENGTH_LONG).show();
                    return;
                }else {
                    loadingBar.setTitle("Preparando todo...");
                    loadingBar.setMessage("Cargando...");
                    loadingBar.show();
                    loadingBar.setCanceledOnTouchOutside(false);
                    loadingBar.setCancelable(false);

                    HashMap userMap = new HashMap();
                    userMap.put("email",edtEmail.getText().toString());
                    userMap.put("department",btnDepartment.getText().toString());
                    userMap.put("district",btnDistrict.getText().toString());
                    userMap.put("province",btnProvince.getText().toString());
                    userMap.put("address",edtAddress.getText().toString());
                    userRef.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful())
                            {
                                Intent intent = new Intent(RegisterInfo3Activity.this, RegisterInfo4Activity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                loadingBar.dismiss();
                                startActivity(intent);
                                finish();
                            }
                            else
                            {
                                String message = task.getException().getMessage();
                                Toast.makeText(RegisterInfo3Activity.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();

                            }
                        }
                    });
                }

            }
        });

    }
}
