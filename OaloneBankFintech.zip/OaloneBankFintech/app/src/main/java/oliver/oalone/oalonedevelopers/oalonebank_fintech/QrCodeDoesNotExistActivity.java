package oliver.oalone.oalonedevelopers.oalonebank_fintech;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class QrCodeDoesNotExistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_code_does_not_exist);
    }
}
